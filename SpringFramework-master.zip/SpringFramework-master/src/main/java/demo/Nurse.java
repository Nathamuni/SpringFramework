package demo;

public class Nurse implements Staff {
    public void assist(){
        System.out.println("Nurse is assisting");
    }
}
