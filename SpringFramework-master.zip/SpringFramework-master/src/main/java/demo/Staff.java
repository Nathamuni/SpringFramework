package demo;

public interface Staff {
    void assist();
}
